import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Ticket, Copy, Check, Sparkles } from "lucide-react";

const DISMISSED_KEY = "dc_dismissed_announcements";

export default function DiscountAnnouncementPopup() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [activeCode, setActiveCode] = useState(null);
  const [copied, setCopied] = useState(false);

  const { data: me } = useQuery({ queryKey: ["me"], queryFn: () => base44.auth.me().catch(() => null) });
  const { data: codes = [] } = useQuery({
    queryKey: ["discount-announcements"],
    queryFn: () => base44.entities.DiscountCode.list("-created_date", 50),
    enabled: !!me && me.role !== "admin",
  });

  useEffect(() => {
    if (!me || me.role === "admin") return;
    const today = new Date().toISOString().slice(0, 10);
    let dismissed = [];
    try { dismissed = JSON.parse(localStorage.getItem(DISMISSED_KEY) || "[]"); } catch {}
    const candidate = codes.find((c) =>
      c.active && c.is_announcement &&
      (!c.start_date || c.start_date <= today) &&
      (!c.end_date || c.end_date >= today) &&
      !dismissed.includes(c.id)
    );
    if (candidate) {
      setActiveCode(candidate);
      const t = setTimeout(() => setOpen(true), 700);
      return () => clearTimeout(t);
    }
  }, [me, codes]);

  const handleDismiss = () => {
    if (activeCode) {
      try {
        let dismissed = JSON.parse(localStorage.getItem(DISMISSED_KEY) || "[]");
        if (!dismissed.includes(activeCode.id)) dismissed.push(activeCode.id);
        localStorage.setItem(DISMISSED_KEY, JSON.stringify(dismissed));
      } catch {}
    }
    setOpen(false);
  };

  const copyCode = () => {
    if (!activeCode) return;
    navigator.clipboard?.writeText(activeCode.code)
      .then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); })
      .catch(() => {});
  };

  if (!activeCode) return null;

  const discountText = activeCode.discount_type === "percentage"
    ? `${activeCode.discount_value}%`
    : `${activeCode.discount_value} ريال`;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleDismiss(); }}>
      <DialogContent className="max-w-sm gap-0 overflow-hidden p-0">
        <div className="relative bg-gradient-to-br from-primary to-[#00B050] p-6 text-center text-white">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-white/15 mb-3">
            <Ticket className="w-7 h-7" />
          </div>
          <div className="inline-flex items-center gap-1 text-xs bg-white/15 rounded-full px-2.5 py-1 mb-2">
            <Sparkles className="w-3.5 h-3.5" /> عرض خاص لك
          </div>
          <h3 className="text-lg font-bold">
            {activeCode.description || "خصم على اشتراكك"}
          </h3>
        </div>

        <div className="p-6 text-center space-y-4">
          <div>
            <p className="text-sm text-muted-foreground">خصم بقيمة</p>
            <p className="text-3xl font-bold text-primary">{discountText}</p>
          </div>

          <div className="rounded-xl border-2 border-dashed border-primary/40 bg-primary/5 p-3">
            <p className="text-xs text-muted-foreground mb-1">كود الخصم</p>
            <button
              onClick={copyCode}
              className="inline-flex items-center gap-2 font-mono font-bold text-xl text-primary tracking-widest"
              dir="ltr"
            >
              {activeCode.code}
              {copied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex gap-2">
            <Button className="flex-1" onClick={() => { handleDismiss(); navigate("/subscription"); }}>
              اشترك الآن
            </Button>
            <Button variant="outline" className="flex-1" onClick={handleDismiss}>
              تخطّي
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}