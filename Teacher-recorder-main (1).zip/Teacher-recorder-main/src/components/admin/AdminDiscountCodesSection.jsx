import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Ticket, Plus, Pencil, Trash2, Megaphone, Search } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import EmptyState from "@/components/shared/EmptyState";
import DiscountCodeDialog from "@/components/admin/DiscountCodeDialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString("ar-SA-u-ca-gregory") : "—");

export default function AdminDiscountCodesSection() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [delTarget, setDelTarget] = useState(null);
  const [search, setSearch] = useState("");
  const [announcing, setAnnouncing] = useState(null);

  const { data: codes = [], isLoading } = useQuery({
    queryKey: ["discount-codes"],
    queryFn: () => base44.entities.DiscountCode.list("-created_date", 100),
  });

  const filtered = codes.filter((c) =>
    (c.code || "").toLowerCase().includes(search.trim().toLowerCase()) ||
    (c.description || "").includes(search.trim())
  );

  const handleSave = async (payload) => {
    try {
      if (editing) {
        await base44.entities.DiscountCode.update(editing.id, payload);
        toast.success("تم تحديث الكود");
      } else {
        await base44.entities.DiscountCode.create({ ...payload, used_count: 0 });
        toast.success("تم إنشاء الكود");
      }
      qc.invalidateQueries(["discount-codes"]);
    } catch (e) {
      toast.error(e?.response?.data?.error?.message || "تعذر حفظ الكود");
    }
  };

  const toggleActive = async (c) => {
    try {
      await base44.entities.DiscountCode.update(c.id, { active: !c.active });
      qc.invalidateQueries(["discount-codes"]);
    } catch {
      toast.error("تعذر تغيير الحالة");
    }
  };

  const toggleAnnouncement = async (c) => {
    setAnnouncing(c.id);
    try {
      await base44.entities.DiscountCode.update(c.id, { is_announcement: !c.is_announcement });
      qc.invalidateQueries(["discount-codes"]);
      toast.success(!c.is_announcement ? "تم نشر الكود كإعلان للمستخدمين" : "تم إيقاف نشر الكود");
    } catch {
      toast.error("تعذر تحديث حالة النشر");
    } finally {
      setAnnouncing(null);
    }
  };

  const confirmDelete = async () => {
    if (!delTarget) return;
    try {
      await base44.entities.DiscountCode.delete(delTarget.id);
      qc.invalidateQueries(["discount-codes"]);
      toast.success("تم حذف الكود");
    } catch {
      toast.error("تعذر حذف الكود");
    } finally {
      setDelTarget(null);
    }
  };

  return (
    <Card>
      <CardHeader className="py-3 flex-row items-center justify-between space-y-0">
        <CardTitle className="text-sm flex items-center gap-2">
          <Ticket className="w-4 h-4 text-primary" /> أكواد الخصم
        </CardTitle>
        <Button size="sm" className="gap-1" onClick={() => { setEditing(null); setOpen(true); }}>
          <Plus className="w-4 h-4" /> كود جديد
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="بحث بالكود أو الوصف..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-10 h-9" />
        </div>

        {isLoading ? (
          <p className="text-center text-muted-foreground py-8">جارٍ التحميل...</p>
        ) : filtered.length === 0 ? (
          <EmptyState icon={Ticket} title="لا توجد أكواد خصم" description="أنشئ كود خصم للاشتراكات والمدفوعات" />
        ) : (
          <div className="space-y-2 max-h-[28rem] overflow-y-auto">
            {filtered.map((c) => {
              const today = new Date().toISOString().slice(0, 10);
              const expired = c.end_date && today > c.end_date;
              return (
                <div key={c.id} className="rounded-lg border p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-primary" dir="ltr">{c.code}</span>
                        <Badge variant={c.active ? "success" : "secondary"}>{c.active ? "مفعّل" : "معطّل"}</Badge>
                        <Badge variant="outline">
                          {c.discount_type === "percentage" ? `${c.discount_value}%` : `${c.discount_value} ريال`}
                        </Badge>
                        {c.is_announcement && (
                          <Badge variant="outline" className="gap-1 text-accent border-accent/40">
                            <Megaphone className="w-3 h-3" /> منشور كإعلان
                          </Badge>
                        )}
                        {expired && <Badge variant="destructive">منتهٍ</Badge>}
                      </div>
                      {c.description && <p className="text-xs text-muted-foreground mt-1">{c.description}</p>}
                      <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground mt-1.5">
                        <span>التفعيل: {fmtDate(c.start_date)}</span>
                        <span>الانتهاء: {fmtDate(c.end_date)}</span>
                        <span>الاستخدام: {c.used_count || 0}{c.max_usage ? ` / ${c.max_usage}` : " / غير محدود"}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => toggleAnnouncement(c)}
                        disabled={announcing === c.id}
                        title={c.is_announcement ? "إيقاف النشر كإعلان" : "نشر كإعلان للمستخدمين"}
                      >
                        <Megaphone className={cn("w-4 h-4", c.is_announcement ? "text-accent" : "text-muted-foreground")} />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(c); setOpen(true); }} title="تعديل">
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDelTarget(c)} title="حذف">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Switch checked={c.active} onCheckedChange={() => toggleActive(c)} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>

      <DiscountCodeDialog open={open} onOpenChange={setOpen} onSave={handleSave} editing={editing} />

      <AlertDialog open={!!delTarget} onOpenChange={(o) => !o && setDelTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الكود "{delTarget?.code}"؟</AlertDialogTitle>
            <AlertDialogDescription>لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}