import html2canvas from "html2canvas";

// انتظر تحميل كل الصور داخل العقدة (أو فشلها) قبل الالتقاط حتى لا يُرسّم html2canvas
// صورة فارغة أو يلجأ لصورة موصدة تلوّث الكانفس.
async function waitForImages(container) {
  const imgs = Array.from(container.querySelectorAll("img"));
  if (imgs.length === 0) return;
  await Promise.all(
    imgs.map((img) => {
      if (img.complete && img.naturalWidth > 0) return Promise.resolve();
      return new Promise((resolve) => {
        const done = () => resolve();
        img.addEventListener("load", done, { once: true });
        img.addEventListener("error", done, { once: true });
        setTimeout(done, 4000); // احتياط: لا نعلّق التصدير indefinitely
      });
    })
  );
}

async function renderToCanvas(node) {
  await new Promise((r) => setTimeout(r, 120));
  return html2canvas(node, {
    scale: 2,
    useCORS: true,
    allowTaint: false,
    backgroundColor: "#ffffff",
    logging: false,
  });
}

function buildPdfFromCanvas(canvas, fileName, opts) {
  const imgData = canvas.toDataURL("image/jpeg", 0.92);
  return import("jspdf").then(({ default: jsPDF }) => {
    const pdf = new jsPDF({
      orientation: opts.landscape ? "landscape" : "portrait",
      unit: "mm",
      format: "a4",
    });
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const imgW = pageW;
    const imgH = (canvas.height * imgW) / canvas.width;
    let heightLeft = imgH;
    let position = 0;
    pdf.addImage(imgData, "JPEG", 0, position, imgW, imgH);
    heightLeft -= pageH;
    while (heightLeft > 0) {
      position -= pageH;
      pdf.addPage();
      pdf.addImage(imgData, "JPEG", 0, position, imgW, imgH);
      heightLeft -= pageH;
    }
    pdf.save(fileName);
  });
}

export async function captureNodeToPdf(node, fileName = "report.pdf", opts = {}) {
  await waitForImages(node);

  let canvas;
  try {
    canvas = await renderToCanvas(node);
    // تحقق من تلوّث الكانفس قبل البناء
    canvas.toDataURL("image/jpeg", 0.92);
  } catch {
    // الكانفس ملوّث بصورة خارجية — أعد الالتقاط بعد إزالة الصور لضمان إنشاء الملف
    const clone = node.cloneNode(true);
    clone.querySelectorAll("img").forEach((img) => img.remove());
    canvas = await renderToCanvas(clone);
  }

  await buildPdfFromCanvas(canvas, fileName, opts);
}