import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// دالة إدارية آمنة: تحديث حقول اشتراك مستخدم عبر صلاحية الخدمة (asServiceRole).
// يُسمح باستدعائها لمدير النظام فقط؛ أي استدعاء من مستخدم عادي (من واجهة غير إدارية
// أو من Console المتصفح) يُرفض بـ 403. تمنع تعديل حقول الاشتراك مباشرةً من العميل.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    let caller = null;
    try {
      caller = await base44.auth.me();
    } catch (_e) { caller = null; }
    if (!caller || caller.role !== "admin") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    // تحقق مزدوج: تأكيد دور الأدمن من السجل المخزّن (غير قابل للتزوير من العميل)
    const callerRecord = await base44.asServiceRole.entities.User.get(caller.id).catch(() => null);
    if (!callerRecord || callerRecord.role !== "admin") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const body = await req.json();
    const args = body?.args ?? body ?? {};
    const targetId = args.user_id;
    if (!targetId) {
      return Response.json({ error: "user_id required" }, { status: 400 });
    }
    // حقول مسموح بها فقط — لا يمكن للمستدعي تجاوزها إلى حقول أخرى
    const ALLOWED = [
      "subscription_plan", "subscription_start", "subscription_end",
      "account_type", "subscription_status", "full_name", "ministry_number",
      "phone"
    ];
    const update = {};
    for (const k of ALLOWED) {
      if (k in args) update[k] = args[k];
    }
    if (Object.keys(update).length === 0) {
      return Response.json({ error: "no updatable fields" }, { status: 400 });
    }
    await base44.asServiceRole.entities.User.update(targetId, update);

    // تسجيل العملية الحساسة في سجل التدقيق (defense-in-depth)
    try {
      await base44.asServiceRole.entities.AuditLog.create({
        target_user_id: targetId,
        action: "account_edit",
        executor_id: caller.id,
        executor_name: caller.full_name || caller.email || "",
        details: JSON.stringify({ updated_fields: Object.keys(update) }),
      });
    } catch (_e) { /* تجاهل خطأ السجل */ }

    // إغلاق طلب الاشتراك المرتبط إن وُجد
    if (args.request_id && args.request_status) {
      try {
        await base44.asServiceRole.entities.Subscription.update(args.request_id, {
          status: args.request_status
        });
      } catch (_e) { /* تجاهل خطأ تحديث الطلب */ }
    }
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});